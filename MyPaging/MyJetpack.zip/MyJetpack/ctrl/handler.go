package ctrl

import (
	"github.com/gin-gonic/gin"
	"math/rand"
	"strconv"
	"time"
)

func GetPagingPDS(c *gin.Context) {
	start := c.DefaultQuery("start","")
	count := c.DefaultQuery("count", "")

	var startInt = 0
	var countInt = 8
	if start != "" {
		startInt ,_ = strconv.Atoi(start)
	}
	if count != "" {
		countInt, _ = strconv.Atoi(count)
	}

	datas := getDataPDS(startInt, countInt)

	c.JSON(200,gin.H{
		"start":startInt,
		"count":countInt,
		"total":100,
		"data":datas,
	})
}

func getDataPDS(startInt int, countInt int) []Data {
	var datas []Data
	if startInt > 100 {
		datas = make([]Data,0)
		return datas
	}
	for i := startInt; i < startInt+countInt; i++ {
		if i > 100 {
			break
		}
		rand.Seed(time.Now().UnixNano())
		age := rand.Intn(100)
		datas = append(datas, Data{
			ID: i,
			Name: "王大锤"+strconv.Itoa(i),
			Sex: "男",
			Age: age,
			Url: "https://pics4.baidu.com/feed/7a899e510fb30f2416366d1ec2c9044bac4b03e7.jpeg?token=ca836f44321990d24bade2fa6117e5a4",
		})
	}
	return datas
}

func GetPagingPKDS(c *gin.Context) {
	page := c.DefaultQuery("page","")
	pageSize := c.DefaultQuery("pageSize", "")

	var pageInt = 0
	var pageSizeInt = 10
	if page != "" {
		pageInt ,_ = strconv.Atoi(page)
	}
	if pageSize != "" {
		pageSizeInt, _ = strconv.Atoi(pageSize)
	}
	datas, b := getDataPKDS(pageInt, pageSizeInt)
	c.JSON(200,gin.H{
		"data":datas,
		"hasMore":b,
	})
}

func getDataPKDS(pageInt int, sizeInt int) ([]Data,bool) {
	var datas []Data
	var flag  = true
	var index = (pageInt-1) *sizeInt
	var indexCount = index+sizeInt

	if index >= 100 {
		datas = make([]Data,0)
		return datas,false
	}
	for i := index+1; i <= indexCount; i++ {
		if i > 100 {
			flag = false
			break
		}
		rand.Seed(time.Now().UnixNano())
		age := rand.Intn(100)
		datas = append(datas, Data{
			ID: i,
			Name: "王大锤"+strconv.Itoa(i),
			Sex: "男",
			Age: age,
			Url: "https://pics4.baidu.com/feed/7a899e510fb30f2416366d1ec2c9044bac4b03e7.jpeg?token=ca836f44321990d24bade2fa6117e5a4",
		})

	}
	return datas,flag
}

func GetPagingIKDS(c *gin.Context)  {
	since := c.DefaultQuery("since","")
	pageSize := c.DefaultQuery("pageSize", "")
	var sinceInt = 0
	var pageSizeInt = 10
	if since != "" {
		sinceInt ,_ = strconv.Atoi(since)
	}
	if pageSize != "" {
		pageSizeInt, _ = strconv.Atoi(pageSize)
	}
	datas := getDataIKDS(sinceInt, pageSizeInt)
	c.JSON(200,datas)
}

func getDataIKDS(pageInt int, sizeInt int) []Data {
	var datas []Data
	var index = pageInt *sizeInt
	var indexCount = index+sizeInt

	for i := index+1; i <= indexCount; i++ {

		rand.Seed(time.Now().UnixNano())
		age := rand.Intn(100)
		datas = append(datas, Data{
			ID: i,
			Name: "王大锤"+strconv.Itoa(i),
			Sex: "男",
			Age: age,
			Url: "https://pics4.baidu.com/feed/7a899e510fb30f2416366d1ec2c9044bac4b03e7.jpeg?token=ca836f44321990d24bade2fa6117e5a4",
		})

	}
	return datas
}