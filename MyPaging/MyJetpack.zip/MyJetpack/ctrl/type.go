package ctrl

type Data struct {
	ID int `json:"id"`
	Name string `json:"name"`
	Sex string `json:"sex"`
	Age int `json:"age"`
	Url string `json:"url"`
}
