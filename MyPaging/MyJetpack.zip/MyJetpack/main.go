package main

import (
	"MyJetpack/ctrl"
	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()
	r.GET("/paging/dps",ctrl.GetPagingPDS)
	r.GET("/paging/pkds",ctrl.GetPagingPKDS)
	r.GET("/paging/ikds",ctrl.GetPagingIKDS)
	r.Run(":8089")
}
